
# wave-audit-api

A simple Flask API endpoint that takes a brand name and Instagram handle, then returns a mock audit.
